package xocotepetl;

public class Xocotepetl {

    public static void main(String[] args) {
        Inventario in = new Inventario();
        in.setVisible(true);
    }
}
